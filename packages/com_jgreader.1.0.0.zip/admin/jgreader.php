<?php
/*------------------------------------------------------------------------
# com_jgreader - J! GoogleReader
# ------------------------------------------------------------------------
# @author    Alexandros D
# @copyright Copyright (C) 2011 Alexandros D. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# @Website: http://alexd.mplofa.com
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JToolBarHelper::title("Joomla! GReader");
JToolBarHelper::preferences("com_jgreader");

?>
<h3>Instructions</h3>
<p>You may use the OPTIONS button on the toolbar to configure the component. Please ensure that you have provided the correct credentials in order the component to be able to communicate with Google Reader and fetch the requested data.</p>
