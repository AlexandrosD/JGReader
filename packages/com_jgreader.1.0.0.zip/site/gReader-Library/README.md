#gReader Library

PHP class library for providing access to the Google Reader API. Enables authentication and provides public methods for general Google Reader actions.

This project is dual-licensed as GPLv2 and MIT.

Changelog:
- Added UTF-8 support
- Added extra functions
- list functions now return an array instead of HTML
